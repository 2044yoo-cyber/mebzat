// Context-aware placeholder images for the seed dataset.
//
// Every image is a branded Medosha SVG stored locally under public/images/.
// Nothing here contacts an external image service: the app must render its
// demo content fully offline (Supabase is the only network dependency).
//
// Each product/project/company maps to a descriptive category, and that
// category resolves to a local asset — so the image always suits the item
// instead of being a random photo. Unmatched items fall back to the generic
// branded placeholder for their kind.

/** Generic branded fallback, used when nothing more specific matches. */
export const BRAND_PLACEHOLDER = "/images/placeholders/product.svg";
export const PRODUCT_PLACEHOLDER = "/images/placeholders/product.svg";
export const PROJECT_PLACEHOLDER = "/images/placeholders/project.svg";
export const COMPANY_PLACEHOLDER = "/images/placeholders/company.svg";
export const AVATAR_PLACEHOLDER = "/images/placeholders/avatar.svg";
export const COVER_PLACEHOLDER = "/images/placeholders/cover.svg";

function hash(str: string): number {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h) ^ str.charCodeAt(i);
  return h >>> 0;
}

// --- Product mapping -------------------------------------------------------
// Title-specific rules are checked first (top to bottom), then category
// defaults. Each rule resolves to a local asset slug in public/images/products.

const PRODUCT_TITLE_RULES: [RegExp, string][] = [
  [/granite|countertop|marble/i, "construction-materials"],
  [/porcelain|ceramic (floor )?tile|floor tile|vinyl|spc|hardwood|laminate floor|epoxy/i, "flooring"],
  [/sink|kitchen cabinet|modular kitchen|kitchen island|pantry/i, "kitchen"],
  [/wash basin|basin|toilet|water closet|shower|vanity/i, "bathroom"],
  [/faucet|mixer|\btap\b|pipe|ppr|pvc/i, "plumbing"],
  [/wardrobe|closet|dining table|table|desk|chair|sofa|lounge|couch|bed( frame)?|bookshelf|shelf/i, "furniture"],
  [/\bdoor/i, "doors"], // \b so "outdoor" doesn't match
  [/window|tempered glass|glass panel/i, "windows"],
  [/corrugated|metal sheet|roof sheet|truss|waterproof|membrane|roof tile|clay roof|\broof|insulation/i, "roofing"],
  [/primer|putty|coating|paint/i, "paint"],
  [/cement|portland|rebar|reinforc|block|hcb|hollow|sand|aggregate|gravel/i, "construction-materials"],
  [/cable|wire|switch|socket|outlet|distribution board|breaker|panel board/i, "electrical"],
  [/water tank|tank/i, "plumbing"],
  [/solar/i, "solar"],
  [/led|light|lamp|chandelier|pendant/i, "lighting"],
  [/hinge|lock|handle|screw|bolt|nail|tool/i, "hardware"],
];

// Product category slug -> local asset slug.
const PRODUCT_CATEGORY_ASSETS: Record<string, string> = {
  furniture: "furniture",
  kitchen: "kitchen",
  bathroom: "bathroom",
  lighting: "lighting",
  doors: "doors",
  windows: "windows",
  roofing: "roofing",
  paint: "paint",
  flooring: "flooring",
  electrical: "electrical",
  "construction-materials": "construction-materials",
  plumbing: "plumbing",
  solar: "solar",
  hardware: "hardware",
};

/** Local asset slug for a product, or null when nothing maps. */
export function productPhrase(
  title: string,
  categorySlug: string,
): string | null {
  for (const [rule, slug] of PRODUCT_TITLE_RULES) {
    if (rule.test(title)) return slug;
  }
  return PRODUCT_CATEGORY_ASSETS[categorySlug] ?? null;
}

/** Local image for a product. Returns a single-element array: local assets
 * are one branded image per category, so a gallery of duplicates would be
 * meaningless. `_count` is accepted for call-site compatibility. */
export function productImages(
  title: string,
  categorySlug: string,
  _key: string,
  _count?: number,
): string[] {
  const slug = productPhrase(title, categorySlug);
  return [slug ? `/images/products/${slug}.svg` : PRODUCT_PLACEHOLDER];
}

// --- Project mapping -------------------------------------------------------

const PROJECT_NOUN_RULES: [RegExp, string][] = [
  [/villa|estate|complex|residence|house/i, "residential"],
  [/apartment|tower/i, "commercial"],
  [/plaza|mall|showroom|commercial|office/i, "commercial"],
  [/lodge|hotel|hospitality/i, "hospitality"],
  [/pavilion/i, "other"],
];

const PROJECT_TYPE_ASSETS: Record<string, string> = {
  residential: "residential",
  commercial: "commercial",
  industrial: "industrial",
  hospitality: "hospitality",
  institutional: "institutional",
  mixed_use: "mixed-use",
  landscape: "landscape",
  interior: "interior",
  renovation: "renovation",
  other: "other",
};

/** Local asset slug for a project. `_style` is kept for call-site
 * compatibility — local assets are chosen by building type, not by style. */
export function projectPhrase(
  title: string,
  buildingType: string,
  _style?: string,
): string {
  for (const [rule, slug] of PROJECT_NOUN_RULES) {
    if (rule.test(title)) return slug;
  }
  return PROJECT_TYPE_ASSETS[buildingType] ?? "other";
}

export function projectImages(
  title: string,
  buildingType: string,
  style: string,
  _key: string,
  _count?: number,
): string[] {
  return [`/images/projects/${projectPhrase(title, buildingType, style)}.svg`];
}

// --- Company mapping -------------------------------------------------------

const COMPANY_RULES: [RegExp, string][] = [
  [/architect|design/i, "architecture"],
  [/interior|furniture/i, "interior"],
  [/steel/i, "steel"],
  [/cement|material|supplier|trading/i, "materials"],
  [/contractor|construction|builder/i, "contractor"],
  [/developer|real estate/i, "developer"],
  [/engineering/i, "engineering"],
];

/** Local asset slug for a company category. */
export function companyPhrase(category: string): string {
  for (const [rule, slug] of COMPANY_RULES) {
    if (rule.test(category)) return slug;
  }
  return "general";
}

export function companyCover(category: string, _key?: string): string {
  return `/images/companies/${companyPhrase(category)}.svg`;
}

/** Decorative profile cover — branded, on-theme, always local. */
export function architectureCover(_key?: string): string {
  return COVER_PLACEHOLDER;
}

// --- Avatars ---------------------------------------------------------------

/** Number of branded avatar variants in public/images/avatars. */
const AVATAR_COUNT = 12;

/** Deterministic branded avatar for a seed string (name, username, id). */
export function avatarImage(seed: string): string {
  const n = (hash(seed) % AVATAR_COUNT) + 1;
  return `/images/avatars/avatar-${String(n).padStart(2, "0")}.svg`;
}
