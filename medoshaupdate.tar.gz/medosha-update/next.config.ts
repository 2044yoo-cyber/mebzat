import type { NextConfig } from "next";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseHost = supabaseUrl ? new URL(supabaseUrl).hostname : undefined;

const nextConfig: NextConfig = {
  images: {
    // Allow SVGs (the branded Medosha placeholders under public/images, and
    // any SVG a user uploads as a company logo) but neutralize them: served
    // as attachments under a sandbox CSP that blocks scripts, per Next.js
    // guidance.
    dangerouslyAllowSVG: true,
    contentDispositionType: "attachment",
    contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
    // Supabase Storage for this project is the ONLY permitted remote image
    // source, and its host is derived from the environment so each
    // deployment allows its own project. Scoped to /storage/v1/** to cover
    // both the public object route and the image-transformation route.
    //
    // No external image providers are allowed. All demo/placeholder imagery
    // is stored locally under public/images (see scripts/lib/images.ts), so
    // the app renders its content fully offline.
    remotePatterns: supabaseHost
      ? [
          {
            protocol: "https" as const,
            hostname: supabaseHost,
            pathname: "/storage/v1/**",
          },
        ]
      : [],
  },
};

export default nextConfig;
