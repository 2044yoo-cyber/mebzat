# Medosha — Phase 1 setup

Phase 1 covers authentication, role-based onboarding, and a basic profile
shell. This is what's needed to run it against a real Supabase project.

## 1. Create a Supabase project

1. Create a project at [supabase.com](https://supabase.com).
2. Go to **Project Settings → API** and copy the Project URL, `anon` key,
   and `service_role` key into `.env.local` (see `.env.example`):

   ```
   NEXT_PUBLIC_SUPABASE_URL=
   NEXT_PUBLIC_SUPABASE_ANON_KEY=
   SUPABASE_SERVICE_ROLE_KEY=
   NEXT_PUBLIC_SITE_URL=http://localhost:3000
   ```

## 2. Run the database migrations

Open **SQL Editor** in the Supabase dashboard and run, in order:

1. [`supabase/migrations/0001_init_profiles.sql`](supabase/migrations/0001_init_profiles.sql)
   — creates the `profiles` table, RLS policies, the `avatars`/`covers`
   storage buckets, and the trigger that creates a profile row whenever a
   user signs up.
2. [`supabase/migrations/0002_progressive_profile.sql`](supabase/migrations/0002_progressive_profile.sql)
   — makes `email` nullable (phone-only sign-ups have none) and updates
   the trigger to auto-generate a username so new users never have to
   fill in a form before landing on the dashboard.
3. [`supabase/migrations/0003_profile_views.sql`](supabase/migrations/0003_profile_views.sql)
   — adds the `profile_views` counter shown on the dashboard stats and
   the owner's own profile header, incremented whenever someone else
   views a profile at `/u/[username]`.
4. [`supabase/migrations/0004_projects.sql`](supabase/migrations/0004_projects.sql)
   — adds the `projects` and `project_images` tables, the
   `project-images` storage bucket, RLS (published projects are public,
   drafts and writes owner-only), and a view counter. Powers the Project
   Showcase (`/projects`, `/projects/new`, `/projects/[id]`) and the
   projects section on profiles.
5. [`supabase/migrations/0005_marketplace.sql`](supabase/migrations/0005_marketplace.sql)
   — adds the marketplace: `product_categories` (seeded), `products`,
   `product_images`, and `product_favorites` tables, the `product-images`
   storage bucket, RLS (published products public; drafts, writes, and
   favorites owner-only), a view counter, and full-text search index.
   Powers `/marketplace`, `/marketplace/[id]`, `/products`,
   `/products/new`, and `/saved`. The marketplace pages render an empty
   "being set up" state until this migration is applied.
6. [`supabase/migrations/0006_companies.sql`](supabase/migrations/0006_companies.sql)
   — adds the `companies` and `company_claims` tables, the `company-assets`
   storage bucket, RLS (public directory; owner-only writes; imported rows
   stay read-only until claimed), an `approve_company_claim` RPC
   (service-role), and a view counter. Powers the business directory
   (`/companies`, `/companies/[slug]`) and the claim flow. Companies can be
   imported without a user account (unclaimed) and claimed later.

If you use the Supabase CLI instead: `supabase link` then `supabase db push`.

**Without these, signup will fail** once Supabase's own email/rate-limit
checks pass — the trigger that creates a profile row has nothing to
insert into, which aborts the whole signup transaction.

### Seed development data (optional)

Once the migrations above are applied, populate the app with a fictional
demo dataset (50 users, 20 companies, 50 projects, 200 products). The data
is **for development/testing/demos only** — all names, emails, and images
are fictional or generated placeholders (no real people). It reads your
service-role key from `.env.local`.

```bash
npm run seed
```

The script is **idempotent** — safe to re-run; it matches users by email
and upserts everything else on a stable key. Demo logins are
`demo01@medosha.test` … `demo50@medosha.test` (password
`medosha-demo-1234`).

Product, project, and company images are **context-matched branded Medosha
assets stored locally** in `public/images/` — each item's title/category
maps to a local SVG (`scripts/lib/images.ts`), so a kitchen product shows a
kitchen image and unmatched items fall back to a branded placeholder. No
image is ever requested from an external provider, so the demo dataset
renders fully offline (Supabase is the only network dependency).

### Migrate legacy external image URLs

Databases seeded by earlier versions may still hold external image URLs
(picsum, pollinations, dicebear). Rewrite them to local branded assets:

```bash
npm run migrate:images            # dry run — reports, changes nothing
npm run migrate:images -- --apply # write the replacements
```

Supabase Storage URLs are left untouched — they are first-party uploads.

To import "unclaimed" business listings (the Business Import system) —
businesses that exist without a user account and show a "Claim this
business" button until an owner verifies ownership:

```bash
npm run import:businesses            # imports scripts/data/businesses.sample.json
npm run import:businesses path.json  # or a custom source file
```

Both scripts fail fast with a clear message if the required migrations
haven't been applied yet.

## 3. Configure Auth URLs

In **Authentication → URL Configuration**:

- **Site URL**: `http://localhost:3000` (and your production domain later).
- **Redirect URLs**: add `http://localhost:3000/auth/callback` and your
  production equivalent.

## 4. Enable Google sign-in

In **Authentication → Providers → Google**:

1. Create an OAuth client in the
   [Google Cloud Console](https://console.cloud.google.com/apis/credentials).
2. Set the authorized redirect URI to the value Supabase shows on that
   provider page (`https://<project-ref>.supabase.co/auth/v1/callback`).
3. Paste the Client ID and Secret into Supabase and enable the provider.

## 5. Enable phone sign-in

In **Authentication → Providers → Phone**, enable it and configure an SMS
provider (Twilio, MessageBird, or Vonage). Without this, the phone tab on
signup/login will fail when sending a code.

## 6. Email templates (recommended)

The app supports both of Supabase's confirmation link formats:

- **Default (PKCE `code` param)** — works out of the box, handled by
  `src/app/auth/callback/route.ts`.
- **Token hash format** — if you customize templates to the newer pattern
  below, they're handled by `src/app/auth/confirm/route.ts`:

  ```
  {{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type={{ .Type }}&next=/dashboard
  ```

Either works; you don't have to change the default templates for Phase 1.

## 7. Run it

```bash
npm install
npm run dev
```

Visit `http://localhost:3000` and sign up — you land straight on the
dashboard with a "Complete your profile" card. Fill in the rest whenever
you want via **Edit profile**.

Note: Supabase's default (non-custom-SMTP) email sending has a low rate
limit, and rejects some non-deliverable domains (e.g. `example.com`) as
invalid. Use a real inbox or a disposable one like `@mailinator.com` when
testing signup.

## Known dev-mode quirk

In `next dev` (Turbopack), the `/login` route's Suspense boundary can
occasionally get stuck showing its loading skeleton instead of revealing
the form — a Next.js 16.2 Turbopack dev-streaming quirk, not a code bug.
It does not reproduce in production (`next build && next start`). If you
hit it locally, a hard refresh resolves it.
