import type { Metadata } from "next";
import { MessageSquare } from "lucide-react";

import { ConversationList } from "@/components/messages/conversation-list";
import { getConversations } from "@/lib/data/messages";

export const metadata: Metadata = { title: "Messages" };

export default async function MessagesPage() {
  const conversations = await getConversations();

  return (
    <div className="grid h-[calc(100vh-10rem)] min-h-0 overflow-hidden rounded-2xl border bg-card md:grid-cols-[22rem_1fr]">
      <div className="min-h-0 md:border-r">
        <ConversationList conversations={conversations} />
      </div>

      {/* The list fills the screen on mobile; this pane appears from md up. */}
      <div className="hidden min-h-0 flex-col items-center justify-center gap-3 p-10 text-center md:flex">
        <div className="flex size-12 items-center justify-center rounded-2xl border bg-muted/40 text-muted-foreground">
          <MessageSquare className="size-5" />
        </div>
        <p className="font-medium">Select a conversation</p>
        <p className="max-w-xs text-sm text-muted-foreground">
          Choose a thread on the left, or start a new one to reach a
          professional, supplier, or company.
        </p>
      </div>
    </div>
  );
}
