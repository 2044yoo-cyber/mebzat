import { redirect } from "next/navigation";

import { DashboardNav } from "@/components/layout/dashboard-nav";
import { getUnreadCount } from "@/lib/data/messages";
import { createClient } from "@/lib/supabase/server";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const [{ data: profile }, unreadCount] = await Promise.all([
    supabase
      .from("profiles")
      .select("full_name, avatar_url")
      .eq("id", user.id)
      .single(),
    getUnreadCount(),
  ]);

  return (
    <div className="flex min-h-full flex-col">
      <DashboardNav
        viewerId={user.id}
        unreadCount={unreadCount}
        profile={{
          fullName: profile?.full_name ?? null,
          email: user.email ?? null,
          avatarUrl: profile?.avatar_url ?? null,
        }}
      />
      <main className="mx-auto w-full max-w-6xl flex-1 px-6 py-10">
        {children}
      </main>
    </div>
  );
}
